# WesterosCraft Resource Pack Repository #

This is the current repository for the resource pack for WesterosCraft.  

This branch (v1.16.5) is specifically for the v1.16.5 client and server (next version update).
